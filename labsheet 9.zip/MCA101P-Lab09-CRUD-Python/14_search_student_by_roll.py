"""
Program 14: Search for a specific student by roll number (id)

Sample Input/Output:
    Enter roll number: 1
    Found -> ID: 1, Name: Amit, Age: 21, Marks: 85.0
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        roll = int(input("Enter roll number: "))
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("SELECT id, name, age, marks FROM students WHERE id = ?", (roll,))
        row = cur.fetchone()
        if row:
            print(f"Found -> ID: {row[0]}, Name: {row[1]}, Age: {row[2]}, Marks: {row[3]}")
        else:
            print(f"No student found with roll number {roll}.")
    except ValueError:
        print("Error: Roll number must be an integer.")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
