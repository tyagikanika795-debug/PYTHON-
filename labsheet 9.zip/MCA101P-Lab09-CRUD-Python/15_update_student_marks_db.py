"""
Program 15: Update the marks of a student using roll number (UPDATE operation)

Sample Input/Output:
    Enter roll number: 1
    Enter new marks: 90
    Marks updated successfully.
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        roll = int(input("Enter roll number: "))
        marks = float(input("Enter new marks: "))
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("UPDATE students SET marks = ? WHERE id = ?", (marks, roll))
        conn.commit()
        # rowcount tells how many rows were changed
        if cur.rowcount:
            print("Marks updated successfully.")
        else:
            print(f"No student found with roll number {roll}.")
    except ValueError:
        print("Error: Roll number and marks must be numeric.")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
