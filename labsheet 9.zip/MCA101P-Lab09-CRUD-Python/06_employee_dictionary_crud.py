"""
Program 6: CRUD operations on a dictionary of employee data

Sample Run:
    1. Add  2. View  3. Update  4. Delete  5. Exit
    Enter choice: 1
    Employee ID: 101
    Name: Sohan
    Department: IT
    Salary: 50000
    Employee added successfully.
"""

# key = employee id, value = dictionary of details
employees = {
    101: {"name": "Sohan", "dept": "IT", "salary": 50000.0},
}


def add_employee():
    emp_id = int(input("Employee ID: "))
    if emp_id in employees:
        print("Employee ID already exists.")
        return
    name = input("Name: ").strip()
    dept = input("Department: ").strip()
    salary = float(input("Salary: "))
    employees[emp_id] = {"name": name, "dept": dept, "salary": salary}
    print("Employee added successfully.")


def view_employees():
    if not employees:
        print("No employee data.")
        return
    print(f"{'ID':<6} {'Name':<12} {'Dept':<10} {'Salary':<10}")
    for eid, d in employees.items():
        print(f"{eid:<6} {d['name']:<12} {d['dept']:<10} {d['salary']:<10}")


def update_employee():
    emp_id = int(input("Employee ID to update: "))
    if emp_id not in employees:
        print("Employee not found.")
        return
    new_salary = float(input("New salary: "))
    employees[emp_id]["salary"] = new_salary
    print("Employee updated successfully.")


def delete_employee():
    emp_id = int(input("Employee ID to delete: "))
    if employees.pop(emp_id, None) is None:
        print("Employee not found.")
    else:
        print("Employee deleted successfully.")


def main():
    while True:
        print("\n1. Add  2. View  3. Update  4. Delete  5. Exit")
        try:
            choice = int(input("Enter choice: "))
            if choice == 1:
                add_employee()
            elif choice == 2:
                view_employees()
            elif choice == 3:
                update_employee()
            elif choice == 4:
                delete_employee()
            elif choice == 5:
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Choose 1-5.")
        except ValueError:
            print("Error: Invalid numeric input.")


if __name__ == "__main__":
    main()
