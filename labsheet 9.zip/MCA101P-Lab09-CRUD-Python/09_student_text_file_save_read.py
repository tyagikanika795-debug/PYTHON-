"""
Program 9: Save student data into a text file and read it back

Sample Output:
    Data saved to students.txt
    Reading back from file:
    1,Amit,85.0
    2,Riya,92.0
"""

FILE_NAME = "students.txt"

students = [(1, "Amit", 85.0), (2, "Riya", 92.0), (3, "Karan", 78.5)]


def save_to_file():
    """Write each student as one comma-separated line."""
    try:
        with open(FILE_NAME, "w") as f:  # 'with' closes the file automatically
            for roll, name, marks in students:
                f.write(f"{roll},{name},{marks}\n")
        print(f"Data saved to {FILE_NAME}")
    except IOError as e:
        print("File write error:", e)


def read_from_file():
    """Read the file and print every line."""
    try:
        with open(FILE_NAME, "r") as f:
            print("Reading back from file:")
            for line in f:
                print(line.strip())
    except FileNotFoundError:
        print("File not found. Save data first.")
    except IOError as e:
        print("File read error:", e)


if __name__ == "__main__":
    save_to_file()
    read_from_file()
