"""
Program 10: CRUD operations on a file - add, view, modify and delete records

Records are stored in records.txt as: id,name,marks (one per line)

Sample Run:
    1. Add  2. View  3. Modify  4. Delete  5. Exit
    Enter choice: 1
    ID: 1
    Name: Amit
    Marks: 85
    Record added.
"""

FILE_NAME = "records.txt"


def load_records():
    """Read all records from file into a list of lists."""
    try:
        with open(FILE_NAME, "r") as f:
            return [line.strip().split(",") for line in f if line.strip()]
    except FileNotFoundError:
        return []  # file does not exist yet -> no records


def save_records(records):
    """Overwrite file with the given records."""
    with open(FILE_NAME, "w") as f:
        for r in records:
            f.write(",".join(r) + "\n")


def add_record():
    rid = input("ID: ").strip()
    if any(r[0] == rid for r in load_records()):
        print("ID already exists.")
        return
    name = input("Name: ").strip()
    marks = str(float(input("Marks: ")))
    with open(FILE_NAME, "a") as f:  # append mode
        f.write(f"{rid},{name},{marks}\n")
    print("Record added.")


def view_records():
    records = load_records()
    if not records:
        print("No records found.")
        return
    for r in records:
        print(f"ID: {r[0]}, Name: {r[1]}, Marks: {r[2]}")


def modify_record():
    rid = input("ID to modify: ").strip()
    records = load_records()
    for r in records:
        if r[0] == rid:
            r[2] = str(float(input("New marks: ")))
            save_records(records)
            print("Record modified.")
            return
    print("Record not found.")


def delete_record():
    rid = input("ID to delete: ").strip()
    records = load_records()
    new_records = [r for r in records if r[0] != rid]
    if len(new_records) == len(records):
        print("Record not found.")
    else:
        save_records(new_records)
        print("Record deleted.")


def main():
    while True:
        print("\n1. Add  2. View  3. Modify  4. Delete  5. Exit")
        try:
            choice = int(input("Enter choice: "))
            if choice == 1:
                add_record()
            elif choice == 2:
                view_records()
            elif choice == 3:
                modify_record()
            elif choice == 4:
                delete_record()
            elif choice == 5:
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Choose 1-5.")
        except ValueError:
            print("Error: Invalid input.")
        except IOError as e:
            print("File error:", e)


if __name__ == "__main__":
    main()
