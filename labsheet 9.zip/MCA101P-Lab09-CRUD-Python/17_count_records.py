"""
Program 17: Count and display the total number of records in the table

Sample Output:
    Total number of records: 2
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM students")
        print("Total number of records:", cur.fetchone()[0])
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
