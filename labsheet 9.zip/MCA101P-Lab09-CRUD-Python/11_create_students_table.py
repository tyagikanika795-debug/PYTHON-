"""
Program 11: Connect to a database and create the table 'students'

Table: students(id, name, age, marks)

Sample Output:
    Connected to database 'students.db'.
    Table 'students' created (or already exists).
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        conn = sqlite3.connect(DB_NAME)  # creates file if missing
        print(f"Connected to database '{DB_NAME}'.")
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id    INTEGER PRIMARY KEY,
                name  TEXT NOT NULL,
                age   INTEGER,
                marks REAL
            )
        """)
        conn.commit()
        print("Table 'students' created (or already exists).")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()  # always close the connection


if __name__ == "__main__":
    main()
