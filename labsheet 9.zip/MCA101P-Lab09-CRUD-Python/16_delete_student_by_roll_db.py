"""
Program 16: Delete a student record using roll number (DELETE operation)

Sample Input/Output:
    Enter roll number to delete: 2
    Record deleted successfully.
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        roll = int(input("Enter roll number to delete: "))
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("DELETE FROM students WHERE id = ?", (roll,))
        conn.commit()
        if cur.rowcount:
            print("Record deleted successfully.")
        else:
            print(f"No student found with roll number {roll}.")
    except ValueError:
        print("Error: Roll number must be an integer.")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
