"""
Program 2: Display all student records from the list (READ operation)

Sample Output:
    Roll   Name          Marks
    1      Amit          85.0
    2      Riya          92.0
    3      Karan         78.5
"""

students = [
    {"roll": 1, "name": "Amit", "marks": 85.0},
    {"roll": 2, "name": "Riya", "marks": 92.0},
    {"roll": 3, "name": "Karan", "marks": 78.5},
]


def display_all(records):
    """Print every record in a table format."""
    if not records:
        print("No records found.")
        return
    print(f"{'Roll':<6} {'Name':<12} {'Marks':<6}")
    print("-" * 26)
    for s in records:
        print(f"{s['roll']:<6} {s['name']:<12} {s['marks']:<6}")


if __name__ == "__main__":
    display_all(students)
