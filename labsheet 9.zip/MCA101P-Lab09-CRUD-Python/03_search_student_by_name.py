"""
Program 3: Search for a student by name in the list

Sample Input/Output:
    Enter name to search: riya
    Student found -> Roll: 2, Name: Riya, Marks: 92.0
"""

students = [
    {"roll": 1, "name": "Amit", "marks": 85.0},
    {"roll": 2, "name": "Riya", "marks": 92.0},
    {"roll": 3, "name": "Karan", "marks": 78.5},
]


def search_by_name(records, name):
    """Return all records whose name matches (case-insensitive)."""
    return [s for s in records if s["name"].lower() == name.lower()]


def main():
    try:
        name = input("Enter name to search: ").strip()
        if not name:
            raise ValueError("Name cannot be empty.")
        result = search_by_name(students, name)
        if result:
            for s in result:
                print(f"Student found -> Roll: {s['roll']}, "
                      f"Name: {s['name']}, Marks: {s['marks']}")
        else:
            print(f"No student named '{name}' found.")
    except ValueError as e:
        print("Error:", e)


if __name__ == "__main__":
    main()
