"""
Program 13: Read and display all records from the table (READ operation)

Sample Output:
    ID    Name         Age   Marks
    1     Amit         21    85.0
    2     Riya         20    92.0
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("SELECT id, name, age, marks FROM students")
        rows = cur.fetchall()
        if not rows:
            print("No records found.")
            return
        print(f"{'ID':<5} {'Name':<12} {'Age':<5} {'Marks':<6}")
        for r in rows:
            print(f"{r[0]:<5} {r[1]:<12} {r[2]:<5} {r[3]:<6}")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
