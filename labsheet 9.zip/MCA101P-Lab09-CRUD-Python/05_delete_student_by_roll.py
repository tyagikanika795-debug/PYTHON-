"""
Program 5: Delete a student record by roll number (DELETE operation)

Sample Input/Output:
    Enter roll number to delete: 3
    Record of Karan (roll 3) deleted successfully.
"""

students = [
    {"roll": 1, "name": "Amit", "marks": 85.0},
    {"roll": 2, "name": "Riya", "marks": 92.0},
    {"roll": 3, "name": "Karan", "marks": 78.5},
]


def delete_by_roll(records, roll):
    """Remove the record with given roll. Returns True if deleted."""
    for s in records:
        if s["roll"] == roll:
            records.remove(s)
            print(f"Record of {s['name']} (roll {roll}) deleted successfully.")
            return True
    return False


def main():
    try:
        roll = int(input("Enter roll number to delete: "))
        if not delete_by_roll(students, roll):
            print(f"No student with roll number {roll} found.")
        print("\nRemaining records:")
        for s in students:
            print(s)
    except ValueError:
        print("Error: Roll number must be an integer.")


if __name__ == "__main__":
    main()
