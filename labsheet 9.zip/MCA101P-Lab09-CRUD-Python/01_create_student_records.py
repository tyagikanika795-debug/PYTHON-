"""
Program 1: Create a list of student records (CREATE operation)

Sample Input/Output:
    How many students do you want to add? 2
    Roll number: 1
    Name: Amit
    Marks: 85
    Roll number: 2
    Name: Riya
    Marks: 92
    Student list created successfully!
    {'roll': 1, 'name': 'Amit', 'marks': 85.0}
    {'roll': 2, 'name': 'Riya', 'marks': 92.0}
"""


def main():
    students = []  # empty list that will hold all student records
    try:
        n = int(input("How many students do you want to add? "))
        for i in range(n):
            print(f"\n--- Student {i + 1} ---")
            roll = int(input("Roll number: "))
            name = input("Name: ").strip()
            marks = float(input("Marks: "))
            # each record is stored as a dictionary
            students.append({"roll": roll, "name": name, "marks": marks})
        print("\nStudent list created successfully!")
        for s in students:
            print(s)
    except ValueError:
        print("Error: Please enter valid numbers for count, roll and marks.")


if __name__ == "__main__":
    main()
