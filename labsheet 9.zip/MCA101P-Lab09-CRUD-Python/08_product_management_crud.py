"""
Program 8: Store and manage product details using CRUD operations

Sample Run:
    1. Create  2. Read  3. Update  4. Delete  5. Exit
    Enter choice: 1
    Product ID: P1
    Name: Keyboard
    Price: 799
    Quantity: 10
    Product created.
"""

products = {}  # key = product id, value = details dictionary


def create_product():
    pid = input("Product ID: ").strip()
    if pid in products:
        print("Product ID already exists.")
        return
    name = input("Name: ").strip()
    price = float(input("Price: "))
    qty = int(input("Quantity: "))
    products[pid] = {"name": name, "price": price, "qty": qty}
    print("Product created.")


def read_products():
    if not products:
        print("No products stored.")
        return
    print(f"{'ID':<6} {'Name':<14} {'Price':<8} {'Qty':<5}")
    for pid, p in products.items():
        print(f"{pid:<6} {p['name']:<14} {p['price']:<8} {p['qty']:<5}")


def update_product():
    pid = input("Product ID to update: ").strip()
    if pid not in products:
        print("Product not found.")
        return
    products[pid]["price"] = float(input("New price: "))
    products[pid]["qty"] = int(input("New quantity: "))
    print("Product updated.")


def delete_product():
    pid = input("Product ID to delete: ").strip()
    if products.pop(pid, None) is None:
        print("Product not found.")
    else:
        print("Product deleted.")


def main():
    while True:
        print("\n1. Create  2. Read  3. Update  4. Delete  5. Exit")
        try:
            choice = int(input("Enter choice: "))
            if choice == 1:
                create_product()
            elif choice == 2:
                read_products()
            elif choice == 3:
                update_product()
            elif choice == 4:
                delete_product()
            elif choice == 5:
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Choose 1-5.")
        except ValueError:
            print("Error: Invalid input.")


if __name__ == "__main__":
    main()
