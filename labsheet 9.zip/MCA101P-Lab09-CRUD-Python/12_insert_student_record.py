"""
Program 12: Insert a new record into the table (CREATE operation)

Sample Input/Output:
    Enter ID: 1
    Enter name: Amit
    Enter age: 21
    Enter marks: 85
    Record inserted successfully.
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        sid = int(input("Enter ID: "))
        name = input("Enter name: ").strip()
        age = int(input("Enter age: "))
        marks = float(input("Enter marks: "))

        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS students "
                    "(id INTEGER PRIMARY KEY, name TEXT NOT NULL, age INTEGER, marks REAL)")
        # '?' placeholders prevent SQL injection
        cur.execute("INSERT INTO students (id, name, age, marks) VALUES (?, ?, ?, ?)",
                    (sid, name, age, marks))
        conn.commit()
        print("Record inserted successfully.")
    except ValueError:
        print("Error: ID, age and marks must be numeric.")
    except sqlite3.IntegrityError:
        print("Error: A student with this ID already exists.")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
