"""
Program 7: Menu-driven CRUD on a list of books (Add, View, Update, Delete)

Sample Run:
    1. Add Book  2. View Books  3. Update Book  4. Delete Book  5. Exit
    Enter choice: 1
    Title: Python Basics
    Author: A. Sharma
    Price: 350
    Book added successfully.
"""

books = []  # list of dictionaries


def add_book():
    title = input("Title: ").strip()
    author = input("Author: ").strip()
    price = float(input("Price: "))
    books.append({"title": title, "author": author, "price": price})
    print("Book added successfully.")


def view_books():
    if not books:
        print("No books available.")
        return
    for i, b in enumerate(books, start=1):
        print(f"{i}. {b['title']} by {b['author']} - Rs.{b['price']}")


def update_book():
    view_books()
    if not books:
        return
    idx = int(input("Book number to update: ")) - 1
    if 0 <= idx < len(books):
        books[idx]["price"] = float(input("New price: "))
        print("Book updated successfully.")
    else:
        print("Invalid book number.")


def delete_book():
    view_books()
    if not books:
        return
    idx = int(input("Book number to delete: ")) - 1
    if 0 <= idx < len(books):
        removed = books.pop(idx)
        print(f"'{removed['title']}' deleted successfully.")
    else:
        print("Invalid book number.")


def main():
    while True:
        print("\n1. Add Book  2. View Books  3. Update Book  4. Delete Book  5. Exit")
        try:
            choice = int(input("Enter choice: "))
            if choice == 1:
                add_book()
            elif choice == 2:
                view_books()
            elif choice == 3:
                update_book()
            elif choice == 4:
                delete_book()
            elif choice == 5:
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Choose 1-5.")
        except ValueError:
            print("Error: Invalid numeric input.")


if __name__ == "__main__":
    main()
