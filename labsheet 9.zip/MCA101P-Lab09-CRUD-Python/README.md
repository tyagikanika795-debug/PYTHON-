# MCA101P – Lab Sheet 09: CRUD Operations using Python

**COER University, Roorkee** | MCA I Semester (Session 2026-2027)

## Objectives
- Understand CRUD (Create, Read, Update, Delete) in Python
- Implement CRUD using lists, dictionaries, files and a database (SQLite)
- Learn data manipulation and data persistence

## Requirements
- Python 3.x (only standard library: `sqlite3`)

## Program List
| # | File | Description |
|---|------|-------------|
| 1 | `01_create_student_records.py` | Create list of student records |
| 2 | `02_display_student_records.py` | Display all records (Read) |
| 3 | `03_search_student_by_name.py` | Search student by name |
| 4 | `04_update_student_marks.py` | Update marks (Update) |
| 5 | `05_delete_student_by_roll.py` | Delete by roll number (Delete) |
| 6 | `06_employee_dictionary_crud.py` | CRUD on employee dictionary |
| 7 | `07_books_menu_crud.py` | Menu-driven CRUD on books list |
| 8 | `08_product_management_crud.py` | Product CRUD |
| 9 | `09_student_text_file_save_read.py` | Save/read student data in text file |
| 10 | `10_file_crud_operations.py` | CRUD on a file |
| 11 | `11_create_students_table.py` | Connect DB & create `students` table |
| 12 | `12_insert_student_record.py` | Insert record (Create) |
| 13 | `13_read_all_students.py` | Display all records (Read) |
| 14 | `14_search_student_by_roll.py` | Search by roll number |
| 15 | `15_update_student_marks_db.py` | Update marks by roll (Update) |
| 16 | `16_delete_student_by_roll_db.py` | Delete by roll (Delete) |
| 17 | `17_count_records.py` | Count total records |
| 18 | `18_display_sorted_by_name.py` | Records sorted by name |
| 19 | `19_highest_marks_student.py` | Student with highest marks |
| 20 | `20_menu_driven_crud_database.py` | Menu-driven DB CRUD application |

## How to Run
```bash
python 01_create_student_records.py
# For database programs, run 11 first (or any of 12-20, they auto-create the table)
python 11_create_students_table.py
python 20_menu_driven_crud_database.py
```

## Implementation Notes
- Every program has comments, a docstring with sample input/output, and `try–except` handling.
- Files use `with open(...)`; database connections are closed in a `finally` block.
- DB table: `students(id INTEGER PRIMARY KEY, name TEXT, age INTEGER, marks REAL)`.
- Parameterised queries (`?`) are used to prevent SQL injection.

## Results
All 20 programs were executed and tested; sample outputs are in each file's docstring.
