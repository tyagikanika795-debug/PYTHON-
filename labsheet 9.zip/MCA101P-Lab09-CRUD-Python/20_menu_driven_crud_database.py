"""
Program 20: Menu-driven Python application for all CRUD operations (SQLite)

Sample Run:
    ===== STUDENT MANAGEMENT SYSTEM =====
    1. Add  2. View All  3. Search  4. Update Marks  5. Delete  6. Exit
    Enter choice: 1
    ID: 1
    Name: Amit
    Age: 21
    Marks: 85
    Record inserted successfully.
"""
import sqlite3

DB_NAME = "students.db"


def get_connection():
    """Open connection and make sure the table exists."""
    conn = sqlite3.connect(DB_NAME)
    conn.execute("CREATE TABLE IF NOT EXISTS students "
                 "(id INTEGER PRIMARY KEY, name TEXT NOT NULL, age INTEGER, marks REAL)")
    return conn


def add_student(conn):
    sid = int(input("ID: "))
    name = input("Name: ").strip()
    age = int(input("Age: "))
    marks = float(input("Marks: "))
    conn.execute("INSERT INTO students VALUES (?, ?, ?, ?)", (sid, name, age, marks))
    conn.commit()
    print("Record inserted successfully.")


def view_students(conn):
    rows = conn.execute("SELECT id, name, age, marks FROM students").fetchall()
    if not rows:
        print("No records found.")
        return
    print(f"{'ID':<5} {'Name':<12} {'Age':<5} {'Marks':<6}")
    for r in rows:
        print(f"{r[0]:<5} {r[1]:<12} {r[2]:<5} {r[3]:<6}")


def search_student(conn):
    sid = int(input("Enter roll number: "))
    row = conn.execute("SELECT id, name, age, marks FROM students WHERE id = ?",
                       (sid,)).fetchone()
    if row:
        print(f"Found -> ID: {row[0]}, Name: {row[1]}, Age: {row[2]}, Marks: {row[3]}")
    else:
        print("Student not found.")


def update_marks(conn):
    sid = int(input("Enter roll number: "))
    marks = float(input("New marks: "))
    cur = conn.execute("UPDATE students SET marks = ? WHERE id = ?", (marks, sid))
    conn.commit()
    print("Marks updated successfully." if cur.rowcount else "Student not found.")


def delete_student(conn):
    sid = int(input("Enter roll number to delete: "))
    cur = conn.execute("DELETE FROM students WHERE id = ?", (sid,))
    conn.commit()
    print("Record deleted successfully." if cur.rowcount else "Student not found.")


def main():
    conn = None
    try:
        conn = get_connection()
        while True:
            print("\n===== STUDENT MANAGEMENT SYSTEM =====")
            print("1. Add  2. View All  3. Search  4. Update Marks  5. Delete  6. Exit")
            try:
                choice = int(input("Enter choice: "))
                if choice == 1:
                    add_student(conn)
                elif choice == 2:
                    view_students(conn)
                elif choice == 3:
                    search_student(conn)
                elif choice == 4:
                    update_marks(conn)
                elif choice == 5:
                    delete_student(conn)
                elif choice == 6:
                    print("Goodbye!")
                    break
                else:
                    print("Invalid choice. Choose 1-6.")
            except ValueError:
                print("Error: Invalid numeric input.")
            except sqlite3.IntegrityError:
                print("Error: This ID already exists.")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()  # always close the connection


if __name__ == "__main__":
    main()
