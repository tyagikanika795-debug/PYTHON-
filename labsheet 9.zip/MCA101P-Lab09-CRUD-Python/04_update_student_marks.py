"""
Program 4: Update a student's marks in the list (UPDATE operation)

Sample Input/Output:
    Enter roll number: 2
    Enter new marks: 95
    Marks updated: Riya 92.0 -> 95.0
"""

students = [
    {"roll": 1, "name": "Amit", "marks": 85.0},
    {"roll": 2, "name": "Riya", "marks": 92.0},
    {"roll": 3, "name": "Karan", "marks": 78.5},
]


def update_marks(records, roll, new_marks):
    """Find student by roll and change marks. Returns True if updated."""
    for s in records:
        if s["roll"] == roll:
            old = s["marks"]
            s["marks"] = new_marks
            print(f"Marks updated: {s['name']} {old} -> {new_marks}")
            return True
    return False


def main():
    try:
        roll = int(input("Enter roll number: "))
        new_marks = float(input("Enter new marks: "))
        if not update_marks(students, roll, new_marks):
            print(f"No student with roll number {roll} found.")
        print("\nUpdated list:")
        for s in students:
            print(s)
    except ValueError:
        print("Error: Roll number and marks must be numeric.")


if __name__ == "__main__":
    main()
