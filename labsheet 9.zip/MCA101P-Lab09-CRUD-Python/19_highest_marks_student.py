"""
Program 19: Find the student with the highest marks from the database

Sample Output:
    Topper -> ID: 2, Name: Riya, Age: 20, Marks: 92.0
"""
import sqlite3

DB_NAME = "students.db"


def main():
    conn = None
    try:
        conn = sqlite3.connect(DB_NAME)
        cur = conn.cursor()
        cur.execute("SELECT id, name, age, marks FROM students "
                    "ORDER BY marks DESC LIMIT 1")
        row = cur.fetchone()
        if row:
            print(f"Topper -> ID: {row[0]}, Name: {row[1]}, Age: {row[2]}, Marks: {row[3]}")
        else:
            print("No records found.")
    except sqlite3.Error as e:
        print("Database error:", e)
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    main()
